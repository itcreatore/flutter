// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'package:flutter_test/flutter_test.dart';

// this is a test to make sure our tests actually catch failures
// see //flutter/dev/bots/test.dart

void main() {
  test('test smoke test -- this test should pass', () async {
    expect(true, isTrue);
  });
}
