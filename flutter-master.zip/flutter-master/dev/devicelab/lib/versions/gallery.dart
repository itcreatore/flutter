// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/// The pinned version of flutter gallery, used for devicelab tests.
const String galleryVersion = '2335d7f1933ac77d6298e304d3adf0cce8fa0b0d';
